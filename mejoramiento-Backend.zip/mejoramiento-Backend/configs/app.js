'use strict'

const express = require('express');
const app = express();
const port = process.env.PORT || 3500;
const addRoutes = require('../src/add/add.routes');

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use('/add', addRoutes);


exports.initServer = () => {
    app.listen(port);
    console.log(`Server http running in port ${port}`);
} 