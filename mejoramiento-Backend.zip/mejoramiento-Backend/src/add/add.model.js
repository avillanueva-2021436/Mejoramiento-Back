'use strict'

const mongoose = require('mongoose');

const addSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    description: {
        type: String,
    },
});

module.exports = mongoose.model('Add', addSchema);