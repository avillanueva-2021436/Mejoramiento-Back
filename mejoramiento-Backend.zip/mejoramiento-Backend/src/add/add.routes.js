'use strict'

const express = require('express');
const api = express.Router();
const addController = require('./add.controller');

api.post('/add', addController.Add);
api.get('/get', addController.get);
api.put('/update/:id', addController.update);
api.delete('/delete/:id', addController.delete);

module.exports = api;