'use strict'
const Add = require('./add.model');

exports.Add = async (req, res) => {
    try {
        let data = req.body;
        let existadd = await Add.findOne({ name: data.name });
        if (existadd) {
            return res.send({ message: 'Game already created' })
        }
        let add = new Add(data);
        await add.save();
        return res.send({ message: 'Game saved sucessfully', add})
    } catch (err) {
        console.error(err);
        return res.status(500).send({ message: 'Error creating game' });
    }
}

exports.get = async (req, res) => {
    try{
        
        let add = await Add.find()
        return res.send({message: 'video game found', add});
    
    }catch{
        console.error(err);
        return res.status(500).send({message: 'Error when searching for video games'});
    }
}

exports.update = async (req, res) => {
    try{
        let data = req.body;
        let nameId = req.params.id;
        let existadd= await Add.findOne({ name: data.name });
        if (existadd) {
            return res.send({ message: 'Video game already created' })
        }
        let updatedAdd = await Add.findOneAndUpdate(
            {_id: nameId},
            data,
            {new: true}
        )
        if(!updatedAdd) return res.send({message: 'Video game not found and not updated'});
        return res.send({message: 'Video game updated:', updatedAdd});
    }catch(err){
        console.error(err);
        return res.status(500).send({message: 'Error updating the video game'})
    }
}

exports.delete = async (req, res) => {
    try {
        let AddId = req.params.id;
        let deletedAdd = await Add.findOneAndDelete({ _id: AddId });
        if (!deletedAdd) return res.status(404).send({ message: 'Game not found and not deleted' });
        return res.send({ message: 'Game deleted sucessfuly' });
    } catch (err) {
        console.error(err);
        return res.status(500).send({ message: 'Error deleting game' });
    }
}
